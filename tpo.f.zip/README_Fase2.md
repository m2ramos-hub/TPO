# PRO-GAMER LOGISTICS — Fase II

Sistema de gestion de inventario.

Materia: Pensamiento Computacional
Profesora: Prof. Ing. Veronica Galati
Equipo: Pro-Gamer Logistics 
- Manuel Dos Ramos 
- Juan Cruz Gallo 
- Lautaro Cordoba 
- Esteban Jumilla 



## De Fase I a Fase II: que cambio y por que

Esta es la Fase II del trabajo. A continuacion se detallan los cambios
realizados respecto de la Fase I.



### Sincronizacion de archivos y modulos

**Antes:** en Fase I el archivo de logica se llamaba "funciones_TPO 2.py" pero
el main  intentaba importar "funciones_tpo", por lo que el programa
no llegaba a compilar. 

**Despues:** los modulos quedaron con nombres limpios y sin espacios
(`auxiliar_f`, `funcion_f`, `main_f`), y los `import` coinciden exactamente con
esos nombres.





### Validacion de datos antes de convertir tipos

**Antes:** algunas partes del programa convertian directamente la entrada del
usuario con `int(input())`, lo que provocaba un `ValueError` y cerraba el
programa si se ingresaba un caracter no numerico.

**Despues:** toda entrada se recibe como texto y se valida primero con
`es_numero_entero()` / `es_numero_decimal()` antes de convertirla con `int()`
o `float()`. Si el dato es invalido, se informa el error y se vuelve a pedir,
sin romper la ejecucion.





### Busqueda en la modificacion de stock

**Antes:** para modificar el stock de un producto, el usuario tenia que
escribir el nombre comercial completo y exacto (por ejemplo "Logitech Teclado
membrana compacto"); un solo espacio o caracter de mas invalidaba la busqueda.

**Despues:** `modificar_stock()` busca el producto por nombre con
`buscar_indice_por_nombre()`, comparando en minusculas, lo que reduce la
posibilidad de error al tipear.






### RT01 — Modularizacion de agregar_producto

**Antes:** la funcion `agregar_producto` repetia tres veces el mismo bloque
`while` para mostrar categorias, productos y marcas numeradas, esto como codigo repetitivo que "claramente puede ser una funcion que reciba una lista y muestre un listado".

**Despues:** se creo `mostrar_listado(lista_opciones, mensaje_peticion)`, una
funcion que muestra cualquier lista numerada, valida el numero
ingresado y devuelve la opcion elegida. `agregar_producto` la llama tres veces
(categorias, productos de la categoria, marcas) en lugar de repetir el codigo.





### RT02 — Ordenamiento sin bandera

**Antes:** `ordenar_inventario` usaba una variable `cambiar = True/False` y
varios `elif` anidados para decidir el intercambio en el metodo burbuja.

**Despues:** el intercambio se decide con un unico `if` compuesto:

```python
if (stocks[j] < stocks[j+1]) or (stocks[j] == stocks[j+1] and nombres[j].lower() > nombres[j+1].lower()):
```

Ordena por stock descendente y, en caso de empate, alfabeticamente. En Fase II
se extendio a las 7 listas paralelas (se agrego `stock_minimo`).





### RT03 — Retorno unico (sin retorno temprano)

**Antes:** `indice_categoria` usaba `return i` dentro del `while` apenas
encontraba la categoria (retorno temprano). `es_numero_decimal` tenia varios
`return False` repartidos en el cuerpo.

**Despues:**
- `indice_categoria` ahora usa `break` para salir del ciclo y un unico
  `return posicion` al final. La diferencia con la version anterior es que
  `break` corta solo el ciclo, mientras que el `return` corta la funcion
  entera — son dos formas distintas de "salir"...
- `es_numero_decimal` se reescribio para que el unico `return` este en la
  ultima linea, evaluando todas las condiciones (longitud, signo, cantidad de
  digitos y de puntos) en una sola expresion booleana.




### RT04 — Docstrings

**Antes:** varias funciones no tenian docstring (se marco
explicitamente en `informe_general`, `ordenar_inventario` y otras).

**Despues:** se fueron agregando docstrings a todas las funciones nuevas y
refactorizadas. 




### RT05 — `if __name__ == "__main__"`

**Antes:** no existia este patron; los modulos no podian probarse de forma
aislada.

**Despues:** cada modulo (`auxiliar_f`, `funcion_f`) tiene una funcion
`prueba()` con un caso de uso minimo, y un bloque `if __name__ == "__main__":`
al final que la ejecuta solo si el archivo se corre directamente, sin
interferir cuando otro modulo lo importa.




### RT06 — Productos precargados

**Antes:** el inventario arrancaba vacio.

**Despues:** las 7 listas paralelas arrancan con 3 productos reales del
catalogo (Teclado Logitech, Monitor Corsair, Mouse Razer) con precios, stock y
stock minimo coherentes.




### RT07 — Sin variables globales

**Antes:** `marcas_disponibles`, `todas_categorias`, `todas_nombres` y las 9
listas de nombres por categoria estaban sueltas en el modulo de funciones,
accesibles globalmente. 

**Despues:** se creo `crear_catalogo()`, una funcion sin parametros que
construye esas listas y las devuelve con `return`. Se llama una sola vez al
inicio del `main`, y las 3 listas resultantes viajan como parametros a
`agregar_producto`, `validar_categoria` e `indice_categoria`, que ya no
dependen de variables globales.

### RT08 — Tecnicas variadas de ciclos

**Antes:** todas las busquedas y validaciones usaban la misma tecnica
(`while` con retorno temprano dentro del `if`).

**Despues:** se diversificaron las tecnicas:
- `procesar_y_buscar_id` (funcion unificada de busqueda/validacion de ID) usa
  `for-else`: el `else` del `for` corre solo si el ciclo termino sin `break`,
  y dentro arranca una busqueda con `while` puro (condicion logica compuesta,
  sin bandera).
- `producto_duplicado` y `nombre_existe_en_catalogo` usan ciclos puros que
  cortan por condicion logica (`while ... and encontrado == -1`).




## Nuevas funcionalidades (RF) agregadas en Fase II
| RF01 | No duplicar producto si coincide marca + nombre + categoria | Implementado (`producto_duplicado`) |
| RF02 | Columna de marca en el informe general | Acordado con la profesora dejarlo como esta |
| RF03 | Colores  (rojo error, verde menus, normal datos) | Implementado |
| RF04 | Septima lista `stock_minimo`, opcion de menu y % de productos en reposicion | Implementado |
| RF05 | Exportar a CSV (separador `;`) los productos en reposicion | Implementado (`exportar_csv`) |
| RF06/RF07 | Modulo de ventas: verifica stock, recargo 10% con tarjeta, vuelto en efectivo | Implementado (`venta`, `calcular_vuelto`) |
| RF08 | ABM del catalogo (alta, baja, modificacion y listado) | Implementado (`gestionar_catalogo`) |

Durante la Fase II surgieron dos puntos donde el equipo evaluo un cambio y
decidio mantener el comportamiento actual:

- **RF02 (columna de marca en el informe):** se conversó con la cátedra y se
  acordó mantener el formato actual del informe general sin una columna
  separada para la marca.
- **`calcular_vuelto` (RF07):** las denominaciones de billetes utilizadas
  (`[100, 50, 20, 10, 5, 1]`) corresponden a dolares (USD), no a pesos
  argentinos, segun el escenario de venta planteado para el equipo.